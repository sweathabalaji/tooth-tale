
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useDental, CheckupResult } from "@/context/DentalContext";
import { DashboardHeader } from "@/components/layout/DashboardHeader";
import { DashboardSidebar } from "@/components/layout/DashboardSidebar";
import { CheckupResultCard } from "@/components/dental/CheckupResultCard";
import { CheckupDetails } from "@/components/dental/CheckupDetails";

const Checkups = () => {
  const { user } = useAuth();
  const { getPatientResults, checkupResults } = useDental();
  const [selectedResult, setSelectedResult] = useState<CheckupResult | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const isPatient = user?.role === 'patient';
  
  // Get results based on user role
  const results = isPatient
    ? getPatientResults(user?.id || '')
    : checkupResults;

  const handleViewResult = (result: CheckupResult) => {
    setSelectedResult(result);
    setDetailsOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <DashboardHeader />
      <div className="flex flex-1">
        <DashboardSidebar />
        
        <main className="flex-1 p-6 overflow-auto">
          <h1 className="text-3xl font-bold mb-6">
            {isPatient ? "My Checkups" : "Completed Checkups"}
          </h1>
          
          {results.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.map((result) => (
                <CheckupResultCard
                  key={result.id}
                  result={result}
                  onView={handleViewResult}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-xl text-muted-foreground">No checkup results found.</p>
            </div>
          )}
        </main>
      </div>
      
      <CheckupDetails
        result={selectedResult}
        isOpen={detailsOpen}
        onClose={() => setDetailsOpen(false)}
      />
    </div>
  );
};

export default Checkups;
