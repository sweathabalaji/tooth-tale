
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useDental, Dentist } from "@/context/DentalContext";
import { DashboardHeader } from "@/components/layout/DashboardHeader";
import { DashboardSidebar } from "@/components/layout/DashboardSidebar";
import { DentistCard } from "@/components/dental/DentistCard";
import { RequestForm } from "@/components/dental/RequestForm";
import { Input } from "@/components/ui/input";
import { SearchIcon } from "lucide-react";

const Dentists = () => {
  const { user } = useAuth();
  const { dentists } = useDental();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDentist, setSelectedDentist] = useState<Dentist | null>(null);
  const [requestFormOpen, setRequestFormOpen] = useState(false);

  const handleSelectDentist = (dentist: Dentist) => {
    setSelectedDentist(dentist);
    setRequestFormOpen(true);
  };

  const filteredDentists = dentists.filter(
    dentist =>
      dentist.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dentist.specialization.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col">
      <DashboardHeader />
      <div className="flex flex-1">
        <DashboardSidebar />
        
        <main className="flex-1 p-6 overflow-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <h1 className="text-3xl font-bold mb-4 md:mb-0">Available Dentists</h1>
            
            <div className="relative w-full md:w-64">
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input 
                placeholder="Search dentists..." 
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
          
          {filteredDentists.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredDentists.map((dentist) => (
                <DentistCard
                  key={dentist.id}
                  dentist={dentist}
                  onSelect={handleSelectDentist}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-xl text-muted-foreground">No dentists found matching your search.</p>
            </div>
          )}
        </main>
      </div>
      
      <RequestForm
        dentist={selectedDentist}
        isOpen={requestFormOpen}
        onClose={() => setRequestFormOpen(false)}
      />
    </div>
  );
};

export default Dentists;
