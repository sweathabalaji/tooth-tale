
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { Navigate, useNavigate } from "react-router-dom";
import { LoginForm } from "@/components/auth/LoginForm";
import { RegisterForm } from "@/components/auth/RegisterForm";
import { Tooth } from "@/components/icons/Tooth";
import { MongoDbTest } from "@/components/MongoDbTest";

const Index = () => {
  const { user } = useAuth();
  const [showLogin, setShowLogin] = useState(true);
  const navigate = useNavigate();

  // Update the auth context to handle navigation
  const handleSuccessfulAuth = () => {
    navigate("/dashboard");
  };

  // Redirect to dashboard if already logged in
  if (user) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <div className="flex-1 p-8 bg-gradient-to-br from-dental-700 to-teal-700 text-white flex flex-col justify-center items-center dental-pattern">
        <div className="max-w-md mx-auto text-center">
          <div className="flex items-center justify-center mb-8">
            <Tooth className="h-16 w-16 text-white" />
          </div>
          <h1 className="text-5xl font-bold mb-6">ToothTale</h1>
          <p className="text-xl mb-8">
            A modern dental checkup system connecting patients with dentists for better oral health management.
          </p>
          <div className="grid grid-cols-2 gap-4 text-center text-sm">
            <div className="bg-white/10 rounded-lg p-4">
              <h3 className="font-bold mb-2">For Patients</h3>
              <p>Request appointments, view your dental records, and export checkup details.</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <h3 className="font-bold mb-2">For Dentists</h3>
              <p>Manage patient checkups, upload images, and provide professional advice.</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex-1 flex flex-col items-center justify-center p-8 bg-gray-50">
        <div className="w-full max-w-md">
          {showLogin ? (
            <LoginForm onSwitchToRegister={() => setShowLogin(false)} />
          ) : (
            <RegisterForm onSwitchToLogin={() => setShowLogin(true)} />
          )}
        </div>
        
        <div className="w-full max-w-md mt-8">
          <MongoDbTest />
        </div>
      </div>
    </div>
  );
};

export default Index;
