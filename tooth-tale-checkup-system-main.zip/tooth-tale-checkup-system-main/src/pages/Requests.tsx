
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useDental, CheckupRequest } from "@/context/DentalContext";
import { DashboardHeader } from "@/components/layout/DashboardHeader";
import { DashboardSidebar } from "@/components/layout/DashboardSidebar";
import { RequestCard } from "@/components/dental/RequestCard";
import { CheckupForm } from "@/components/dental/CheckupForm";

const Requests = () => {
  const { user } = useAuth();
  const { getPatientRequests, getDentistRequests } = useDental();
  const [selectedRequest, setSelectedRequest] = useState<CheckupRequest | null>(null);
  const [checkupFormOpen, setCheckupFormOpen] = useState(false);

  const isPatient = user?.role === 'patient';
  
  // Get requests based on user role
  const requests = isPatient 
    ? getPatientRequests(user?.id || '')
    : getDentistRequests(user?.id || '');

  const handleRequestAction = (request: CheckupRequest) => {
    setSelectedRequest(request);
    setCheckupFormOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <DashboardHeader />
      <div className="flex flex-1">
        <DashboardSidebar />
        
        <main className="flex-1 p-6 overflow-auto">
          <h1 className="text-3xl font-bold mb-6">
            {isPatient ? "My Requests" : "Patient Requests"}
          </h1>
          
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold mb-4">Pending Requests</h2>
              {requests.filter(r => r.status === 'pending').length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {requests
                    .filter(r => r.status === 'pending')
                    .map((request) => (
                      <RequestCard
                        key={request.id}
                        request={request}
                        isDentist={!isPatient}
                        onAction={!isPatient ? handleRequestAction : undefined}
                      />
                    ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No pending requests.</p>
              )}
            </div>
            
            <div className="pt-4">
              <h2 className="text-xl font-semibold mb-4">Completed Requests</h2>
              {requests.filter(r => r.status === 'completed').length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {requests
                    .filter(r => r.status === 'completed')
                    .map((request) => (
                      <RequestCard
                        key={request.id}
                        request={request}
                        isDentist={!isPatient}
                      />
                    ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No completed requests.</p>
              )}
            </div>
            
            {requests.filter(r => r.status === 'cancelled').length > 0 && (
              <div className="pt-4">
                <h2 className="text-xl font-semibold mb-4">Cancelled Requests</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {requests
                    .filter(r => r.status === 'cancelled')
                    .map((request) => (
                      <RequestCard
                        key={request.id}
                        request={request}
                        isDentist={!isPatient}
                      />
                    ))}
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
      
      {!isPatient && (
        <CheckupForm
          request={selectedRequest}
          isOpen={checkupFormOpen}
          onClose={() => setCheckupFormOpen(false)}
        />
      )}
    </div>
  );
};

export default Requests;
