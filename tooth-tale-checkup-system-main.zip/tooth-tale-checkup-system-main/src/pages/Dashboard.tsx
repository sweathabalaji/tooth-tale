
import { useAuth } from "@/context/AuthContext";
import { useDental } from "@/context/DentalContext";
import { DashboardHeader } from "@/components/layout/DashboardHeader";
import { DashboardSidebar } from "@/components/layout/DashboardSidebar";
import { RequestCard } from "@/components/dental/RequestCard";
import { CheckupResultCard } from "@/components/dental/CheckupResultCard";
import { useState } from "react";
import { CheckupResult } from "@/context/DentalContext";
import { CheckupDetails } from "@/components/dental/CheckupDetails";

const Dashboard = () => {
  const { user } = useAuth();
  const { getPatientRequests, getDentistRequests, getPatientResults, checkupResults } = useDental();
  const [selectedResult, setSelectedResult] = useState<CheckupResult | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  const isPatient = user?.role === 'patient';
  
  // Get relevant data based on user role
  const requests = isPatient 
    ? getPatientRequests(user?.id || '')
    : getDentistRequests(user?.id || '');
    
  const results = isPatient
    ? getPatientResults(user?.id || '')
    : checkupResults;

  const pendingRequests = requests.filter(req => req.status === 'pending');

  const handleViewResult = (result: CheckupResult) => {
    setSelectedResult(result);
    setDetailsOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <DashboardHeader />
      <div className="flex flex-1">
        <DashboardSidebar />
        
        <main className="flex-1 p-6 overflow-auto">
          <h1 className="text-3xl font-bold mb-6">
            Welcome, {user?.name}!
          </h1>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-dental-50 border rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-1">Pending Requests</h2>
              <p className="text-4xl font-bold text-dental-600">{pendingRequests.length}</p>
            </div>
            
            <div className="bg-teal-50 border rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-1">Total Checkups</h2>
              <p className="text-4xl font-bold text-teal-600">{results.length}</p>
            </div>
            
            <div className="bg-blue-50 border rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-1">Recent Activity</h2>
              <p className="text-lg text-blue-600">
                {results.length > 0 
                  ? `Last checkup: ${results[0].date}` 
                  : 'No recent checkups'}
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h2 className="text-2xl font-semibold mb-4">Recent Requests</h2>
              {pendingRequests.length > 0 ? (
                <div className="space-y-4">
                  {pendingRequests.slice(0, 3).map((request) => (
                    <RequestCard 
                      key={request.id} 
                      request={request}
                      isDentist={!isPatient}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No pending requests.</p>
              )}
            </div>
            
            <div>
              <h2 className="text-2xl font-semibold mb-4">Recent Checkups</h2>
              {results.length > 0 ? (
                <div className="space-y-4">
                  {results.slice(0, 3).map((result) => (
                    <CheckupResultCard
                      key={result.id}
                      result={result}
                      onView={handleViewResult}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground">No checkup results.</p>
              )}
            </div>
          </div>
        </main>
      </div>
      
      <CheckupDetails
        result={selectedResult}
        isOpen={detailsOpen}
        onClose={() => setDetailsOpen(false)}
      />
    </div>
  );
};

export default Dashboard;
