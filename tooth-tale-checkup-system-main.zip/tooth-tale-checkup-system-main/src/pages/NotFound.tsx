
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Tooth } from "@/components/icons/Tooth";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
      <Tooth className="h-16 w-16 text-dental-600 mb-4" />
      <h1 className="text-5xl font-bold mb-4 text-dental-800">404</h1>
      <p className="text-xl text-gray-600 mb-8 text-center">
        Oops! The page you're looking for isn't available
      </p>
      <Button asChild>
        <Link to="/">Return to Home</Link>
      </Button>
    </div>
  );
};

export default NotFound;
