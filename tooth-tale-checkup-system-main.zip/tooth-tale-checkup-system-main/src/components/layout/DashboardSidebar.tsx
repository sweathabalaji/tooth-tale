
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import { CalendarIcon, FileTextIcon, FileImageIcon, UsersIcon, UserIcon } from "lucide-react";

interface NavItem {
  title: string;
  href: string;
  icon: React.ReactNode;
}

export const DashboardSidebar = () => {
  const { pathname } = useLocation();
  const { user } = useAuth();
  
  const isPatient = user?.role === 'patient';
  
  const patientNavItems: NavItem[] = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: <FileTextIcon className="h-5 w-5" />,
    },
    {
      title: "Dentists",
      href: "/dentists",
      icon: <UsersIcon className="h-5 w-5" />,
    },
    {
      title: "My Requests",
      href: "/requests",
      icon: <CalendarIcon className="h-5 w-5" />,
    },
    {
      title: "My Checkups",
      href: "/checkups",
      icon: <FileImageIcon className="h-5 w-5" />,
    },
  ];

  const dentistNavItems: NavItem[] = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: <FileTextIcon className="h-5 w-5" />,
    },
    {
      title: "Patient Requests",
      href: "/requests",
      icon: <CalendarIcon className="h-5 w-5" />,
    },
    {
      title: "Completed Checkups",
      href: "/checkups",
      icon: <FileImageIcon className="h-5 w-5" />,
    },
    {
      title: "Profile",
      href: "/profile",
      icon: <UserIcon className="h-5 w-5" />,
    },
  ];

  const navItems = isPatient ? patientNavItems : dentistNavItems;

  return (
    <aside className="w-64 shrink-0 border-r h-screen bg-dental-50">
      <nav className="flex flex-col gap-2 p-4">
        {navItems.map((item) => (
          <Button
            key={item.href}
            variant={pathname === item.href ? "secondary" : "ghost"}
            className={cn(
              "justify-start gap-2",
              pathname === item.href && "bg-teal-100 hover:bg-teal-200 text-teal-700"
            )}
            asChild
          >
            <Link to={item.href}>
              {item.icon}
              {item.title}
            </Link>
          </Button>
        ))}
      </nav>
    </aside>
  );
};
