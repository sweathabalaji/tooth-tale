
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dentist, useDental } from "@/context/DentalContext";
import { useAuth } from "@/context/AuthContext";

interface RequestFormProps {
  dentist: Dentist | null;
  isOpen: boolean;
  onClose: () => void;
}

export const RequestForm = ({ dentist, isOpen, onClose }: RequestFormProps) => {
  const [reason, setReason] = useState("");
  const [preferredDate, setPreferredDate] = useState("");
  const { createCheckupRequest } = useDental();
  const { user } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!dentist || !user) return;
    
    createCheckupRequest({
      patientId: user.id,
      patientName: user.name,
      dentistId: dentist.id,
      dentistName: dentist.name,
      reason,
      preferred_date: preferredDate
    });
    
    onClose();
    setReason("");
    setPreferredDate("");
  };

  if (!dentist) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Request Appointment with {dentist.name}</DialogTitle>
          <DialogDescription>
            Fill in the details below to request a dental checkup.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="reason">Reason for visit</Label>
              <Textarea
                id="reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Please describe your dental concern or reason for checkup"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="preferredDate">Preferred date (optional)</Label>
              <Input
                id="preferredDate"
                type="date"
                value={preferredDate}
                onChange={(e) => setPreferredDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Submit Request</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
