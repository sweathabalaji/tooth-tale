
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CheckupRequest, useDental } from "@/context/DentalContext";

interface CheckupFormProps {
  request: CheckupRequest | null;
  isOpen: boolean;
  onClose: () => void;
}

interface ImageUpload {
  imageUrl: string;
  description: string;
}

export const CheckupForm = ({ request, isOpen, onClose }: CheckupFormProps) => {
  const [diagnosis, setDiagnosis] = useState("");
  const [treatment, setTreatment] = useState("");
  const [notes, setNotes] = useState("");
  const [imageUploads, setImageUploads] = useState<ImageUpload[]>([
    { imageUrl: "", description: "" }
  ]);

  const { completeCheckup } = useDental();

  const handleAddImageField = () => {
    setImageUploads([...imageUploads, { imageUrl: "", description: "" }]);
  };

  const handleImageUrlChange = (index: number, value: string) => {
    const newUploads = [...imageUploads];
    newUploads[index].imageUrl = value;
    setImageUploads(newUploads);
  };

  const handleDescriptionChange = (index: number, value: string) => {
    const newUploads = [...imageUploads];
    newUploads[index].description = value;
    setImageUploads(newUploads);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!request) return;
    
    const validImages = imageUploads.filter(upload => upload.imageUrl && upload.description);
    
    if (validImages.length === 0) {
      alert("Please add at least one image with description");
      return;
    }
    
    completeCheckup(
      request.id,
      diagnosis,
      treatment,
      notes,
      validImages.map(upload => ({
        checkupId: request.id,
        imageUrl: upload.imageUrl,
        description: upload.description
      }))
    );
    
    resetForm();
    onClose();
  };

  const resetForm = () => {
    setDiagnosis("");
    setTreatment("");
    setNotes("");
    setImageUploads([{ imageUrl: "", description: "" }]);
  };

  if (!request) return null;

  return (
    <Dialog open={isOpen} onOpenChange={() => {
      resetForm();
      onClose();
    }}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Complete Checkup for {request.patientName}</DialogTitle>
          <DialogDescription>
            Enter checkup results and upload images
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="diagnosis">Diagnosis</Label>
              <Textarea
                id="diagnosis"
                value={diagnosis}
                onChange={(e) => setDiagnosis(e.target.value)}
                placeholder="Enter your diagnosis"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="treatment">Treatment</Label>
              <Textarea
                id="treatment"
                value={treatment}
                onChange={(e) => setTreatment(e.target.value)}
                placeholder="Describe the treatment provided"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any additional notes or recommendations"
                required
              />
            </div>
            
            <div className="border-t pt-4 mt-2">
              <Label className="mb-4 block">Images and Descriptions</Label>
              
              {imageUploads.map((upload, index) => (
                <div key={index} className="grid gap-2 mb-4 p-4 border rounded-md">
                  <Label htmlFor={`imageUrl-${index}`}>Image URL</Label>
                  <Input
                    id={`imageUrl-${index}`}
                    value={upload.imageUrl}
                    onChange={(e) => handleImageUrlChange(index, e.target.value)}
                    placeholder="Enter image URL"
                    required
                  />
                  
                  <Label htmlFor={`description-${index}`} className="mt-2">Description</Label>
                  <Textarea
                    id={`description-${index}`}
                    value={upload.description}
                    onChange={(e) => handleDescriptionChange(index, e.target.value)}
                    placeholder="Describe what this image shows"
                    required
                  />
                </div>
              ))}
              
              <Button
                type="button"
                variant="outline"
                onClick={handleAddImageField}
                className="mt-2"
              >
                Add Another Image
              </Button>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Complete Checkup</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
