
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckupRequest } from "@/context/DentalContext";

interface RequestCardProps {
  request: CheckupRequest;
  isDentist?: boolean;
  onAction?: (request: CheckupRequest) => void;
}

export const RequestCard = ({ request, isDentist = false, onAction }: RequestCardProps) => {
  const getStatusColor = () => {
    switch (request.status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'pending':
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>
              {isDentist ? request.patientName : request.dentistName}
            </CardTitle>
            <CardDescription>
              Request date: {request.requestDate}
            </CardDescription>
          </div>
          <Badge className={getStatusColor()}>
            {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <p className="text-sm font-medium">Reason:</p>
          <p className="text-sm text-muted-foreground">{request.reason}</p>
          {request.preferred_date && (
            <>
              <p className="text-sm font-medium">Preferred date:</p>
              <p className="text-sm text-muted-foreground">{request.preferred_date}</p>
            </>
          )}
        </div>
      </CardContent>
      {request.status === 'pending' && onAction && (
        <CardFooter>
          <Button onClick={() => onAction(request)} className="w-full">
            {isDentist ? "Process Request" : "View Details"}
          </Button>
        </CardFooter>
      )}
    </Card>
  );
};
