
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckupResult } from "@/context/DentalContext";

interface CheckupResultCardProps {
  result: CheckupResult;
  onView: (result: CheckupResult) => void;
}

export const CheckupResultCard = ({ result, onView }: CheckupResultCardProps) => {
  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle>Checkup on {result.date}</CardTitle>
        <CardDescription>By {result.dentistName}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <p className="text-sm font-medium">Diagnosis:</p>
          <p className="text-sm text-muted-foreground">{result.diagnosis}</p>
          <p className="text-sm font-medium">Treatment:</p>
          <p className="text-sm text-muted-foreground">{result.treatment}</p>
          <p className="text-sm font-medium mt-2">Images: {result.images.length}</p>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={() => onView(result)} className="w-full">View Details</Button>
      </CardFooter>
    </Card>
  );
};
