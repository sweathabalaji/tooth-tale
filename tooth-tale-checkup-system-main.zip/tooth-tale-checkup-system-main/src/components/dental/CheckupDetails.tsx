
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CheckupResult } from "@/context/DentalContext";
import { jsPDF } from "jspdf";

interface CheckupDetailsProps {
  result: CheckupResult | null;
  isOpen: boolean;
  onClose: () => void;
}

export const CheckupDetails = ({ result, isOpen, onClose }: CheckupDetailsProps) => {
  const [isExporting, setIsExporting] = useState(false);

  const handleExportPDF = async () => {
    if (!result) return;
    
    setIsExporting(true);
    
    try {
      // Create a new jsPDF instance
      const doc = new jsPDF();
      
      // Add title and basic information
      doc.setFontSize(22);
      doc.text("Dental Checkup Report", 20, 20);
      
      doc.setFontSize(12);
      doc.text(`Patient: ${result.patientName}`, 20, 40);
      doc.text(`Dentist: ${result.dentistName}`, 20, 50);
      doc.text(`Date: ${result.date}`, 20, 60);
      
      doc.setFontSize(16);
      doc.text("Diagnosis:", 20, 80);
      
      doc.setFontSize(12);
      doc.text(result.diagnosis, 20, 90);
      
      doc.setFontSize(16);
      doc.text("Treatment:", 20, 110);
      
      doc.setFontSize(12);
      doc.text(result.treatment, 20, 120);
      
      doc.setFontSize(16);
      doc.text("Notes:", 20, 140);
      
      doc.setFontSize(12);
      doc.text(result.notes, 20, 150);
      
      // Add images section title
      doc.setFontSize(16);
      doc.text("Images and Descriptions:", 20, 170);
      
      // In a real app, you would load and add images to PDF
      doc.setFontSize(12);
      result.images.forEach((image, index) => {
        const yPos = 190 + (index * 20);
        
        // Just add the image descriptions for the mock version
        doc.text(`Image ${index + 1}: ${image.description}`, 20, yPos);
      });
      
      // Save the PDF
      doc.save(`dental-checkup-${result.date}.pdf`);
    } catch (error) {
      console.error("Error exporting PDF:", error);
    }
    
    setIsExporting(false);
  };

  if (!result) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Checkup Results - {result.date}</DialogTitle>
          <DialogDescription>
            Dental checkup performed by {result.dentistName}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <h3 className="font-medium text-lg">Diagnosis</h3>
            <p className="text-muted-foreground">{result.diagnosis}</p>
          </div>
          
          <div className="grid gap-2">
            <h3 className="font-medium text-lg">Treatment</h3>
            <p className="text-muted-foreground">{result.treatment}</p>
          </div>
          
          <div className="grid gap-2">
            <h3 className="font-medium text-lg">Notes</h3>
            <p className="text-muted-foreground">{result.notes}</p>
          </div>
          
          <div className="grid gap-4">
            <h3 className="font-medium text-lg">Images</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {result.images.map((image) => (
                <div key={image.id} className="space-y-2">
                  <img 
                    src={image.imageUrl} 
                    alt={image.description}
                    className="w-full h-48 object-cover rounded-md"
                  />
                  <p className="text-sm text-muted-foreground">
                    {image.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            onClick={handleExportPDF} 
            disabled={isExporting}
          >
            {isExporting ? "Exporting..." : "Export as PDF"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
