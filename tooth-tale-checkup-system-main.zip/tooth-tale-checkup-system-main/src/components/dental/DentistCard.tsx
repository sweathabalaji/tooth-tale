
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dentist } from "@/context/DentalContext";

interface DentistCardProps {
  dentist: Dentist;
  onSelect: (dentist: Dentist) => void;
}

export const DentistCard = ({ dentist, onSelect }: DentistCardProps) => {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-md">
      <div className="aspect-[3/2] relative">
        <img
          src={dentist.imageUrl}
          alt={dentist.name}
          className="object-cover w-full h-full"
        />
      </div>
      <CardHeader className="p-4">
        <CardTitle className="text-xl">{dentist.name}</CardTitle>
        <CardDescription>{dentist.specialization}</CardDescription>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="text-sm text-muted-foreground">
          <p>{dentist.experience} years of experience</p>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button 
          onClick={() => onSelect(dentist)} 
          variant="default"
          className="w-full"
        >
          Request Appointment
        </Button>
      </CardFooter>
    </Card>
  );
};
