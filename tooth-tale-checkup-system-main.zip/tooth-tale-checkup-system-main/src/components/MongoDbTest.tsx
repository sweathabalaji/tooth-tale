
import { useState, useEffect } from 'react';
import { useMongoDb } from '@/hooks/useMongoDb';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/sonner';
import { Loader2, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export const MongoDbTest = () => {
  const [name, setName] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<'loading' | 'success' | 'error' | null>(null);
  
  const { insertOne, find, loading, error } = useMongoDb({ collection: 'demo' });

  useEffect(() => {
    // Load initial data
    loadData();
  }, []);

  useEffect(() => {
    if (error) {
      setConnectionStatus('error');
      toast.error('MongoDB Error: ' + error.message);
    }
  }, [error]);

  const loadData = async () => {
    setConnectionStatus('loading');
    const response = await find();
    if (response?.success && response.data?.data) {
      setResults(response.data.data);
      setConnectionStatus('success');
      toast.success('Connected to MongoDB successfully');
    } else {
      console.log('No data found or error occurred');
      setConnectionStatus('error');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.warning('Please enter a name');
      return;
    }

    const response = await insertOne({ name, createdAt: new Date() });
    if (response?.success) {
      toast.success('Record added successfully!');
      setName('');
      loadData();
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>MongoDB Connection Test</CardTitle>
        <CardDescription>Add and view data from your MongoDB database</CardDescription>
      </CardHeader>
      <CardContent>
        {connectionStatus === 'error' && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Connection to MongoDB failed. Please check your connection string in Supabase secrets.
            </AlertDescription>
          </Alert>
        )}

        {connectionStatus === 'success' && (
          <Alert className="mb-4 bg-green-50 border-green-200">
            <AlertDescription className="text-green-700">
              Successfully connected to MongoDB!
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid w-full items-center gap-2">
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter a name"
            />
          </div>
          <Button type="submit" disabled={loading || !name.trim()}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Adding...
              </>
            ) : (
              'Add to MongoDB'
            )}
          </Button>
        </form>

        <div className="mt-6">
          <h3 className="text-lg font-medium mb-2">Stored Records</h3>
          {loading ? (
            <div className="flex justify-center py-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : results.length > 0 ? (
            <ul className="space-y-2">
              {results.map((item, index) => (
                <li key={index} className="p-2 border rounded">
                  {item.name}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-muted-foreground">No records found</p>
          )}
        </div>
      </CardContent>
      <CardFooter>
        <Button variant="outline" onClick={loadData} disabled={loading} className="w-full">
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Loading...
            </>
          ) : (
            'Refresh Data'
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};
