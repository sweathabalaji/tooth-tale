
import { SVGProps } from "react";

export const Tooth = (props: SVGProps<SVGSVGElement>) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 5.5c-1.074-.586-2.583-.37-3.574.433-1.031.896-1.272 2.393-.708 3.567.576 1.171 1.282 2.15 1.282 4C9 15.5 7.5 17 7.5 17c-.828 1.167-1.083 2.833-.5 3.5 1.886 2 3.5 0 4.5-.5s1.886-1.786 3-2c1.5-.29 2.255 1.064 3 1.5.745.436 2.886 1.814 3.5 0 .33-.982-.673-2.623-1.5-3.5 0 0-1.017-1.239-1.5-2.5-.677-1.863 1.5-2.981 1.5-5.5s-1.5-4-1.5-4c-.826-1.104-1.886-1.5-3-1.5s-3.019.932-3 1.5" />
    </svg>
  );
};
