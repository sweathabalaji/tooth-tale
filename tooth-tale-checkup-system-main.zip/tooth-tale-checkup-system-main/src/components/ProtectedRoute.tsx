
import { Navigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { UserRole } from "@/context/AuthContext";

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: UserRole[];
}

export const ProtectedRoute = ({
  children,
  allowedRoles = ["patient", "dentist"],
}: ProtectedRouteProps) => {
  const { user, isLoading } = useAuth();

  // Show loading or redirect while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse-gentle text-center">
          <div className="h-10 w-10 mx-auto bg-dental-100 rounded-full mb-4"></div>
          <p className="text-dental-600">Loading...</p>
        </div>
      </div>
    );
  }

  // If not logged in, redirect to login page
  if (!user) {
    return <Navigate to="/" replace />;
  }

  // If user doesn't have the required role, redirect to dashboard
  if (!allowedRoles.includes(user.role)) {
    return <Navigate to="/dashboard" replace />;
  }

  // If authenticated and authorized, render the children
  return <>{children}</>;
};
