
import React, { createContext, useContext, useState, ReactNode } from 'react';
import { toast } from '@/components/ui/sonner';
import { User } from './AuthContext';

// Types
export interface Dentist {
  id: string;
  name: string;
  email: string;
  specialization: string;
  experience: number;
  imageUrl: string;
}

export interface CheckupRequest {
  id: string;
  patientId: string;
  patientName: string;
  dentistId: string;
  dentistName: string;
  requestDate: string;
  status: 'pending' | 'completed' | 'cancelled';
  reason: string;
  preferred_date?: string;
}

export interface CheckupImage {
  id: string;
  checkupId: string;
  imageUrl: string;
  description: string;
  uploadDate: string;
}

export interface CheckupResult {
  id: string;
  requestId: string;
  patientId: string;
  patientName: string;
  dentistId: string;
  dentistName: string;
  date: string;
  diagnosis: string;
  treatment: string;
  notes: string;
  images: CheckupImage[];
}

// Mock data
const MOCK_DENTISTS: Dentist[] = [
  {
    id: '1',
    name: 'Dr. Sarah Johnson',
    email: 'sarah.johnson@example.com',
    specialization: 'General Dentistry',
    experience: 8,
    imageUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=300&auto=format&fit=crop'
  },
  {
    id: '2',
    name: 'Dr. Michael Chen',
    email: 'michael.chen@example.com',
    specialization: 'Orthodontics',
    experience: 12,
    imageUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?q=80&w=300&auto=format&fit=crop'
  },
  {
    id: '3',
    name: 'Dr. Jessica Williams',
    email: 'jessica.williams@example.com',
    specialization: 'Pediatric Dentistry',
    experience: 6,
    imageUrl: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?q=80&w=300&auto=format&fit=crop'
  },
];

const MOCK_CHECKUP_REQUESTS: CheckupRequest[] = [
  {
    id: '1',
    patientId: '1',
    patientName: 'John Doe',
    dentistId: '1',
    dentistName: 'Dr. Sarah Johnson',
    requestDate: '2023-04-15',
    status: 'completed',
    reason: 'Regular checkup and cleaning'
  },
  {
    id: '2',
    patientId: '1',
    patientName: 'John Doe',
    dentistId: '2',
    dentistName: 'Dr. Michael Chen',
    requestDate: '2023-05-20',
    status: 'pending',
    reason: 'Tooth pain on lower right side',
    preferred_date: '2023-06-01'
  }
];

const MOCK_CHECKUP_RESULTS: CheckupResult[] = [
  {
    id: '1',
    requestId: '1',
    patientId: '1',
    patientName: 'John Doe',
    dentistId: '1',
    dentistName: 'Dr. Sarah Johnson',
    date: '2023-04-18',
    diagnosis: 'Healthy teeth with minor plaque buildup',
    treatment: 'Professional cleaning performed',
    notes: 'Recommended flossing daily and using fluoride mouthwash',
    images: [
      {
        id: '1',
        checkupId: '1',
        imageUrl: 'https://images.unsplash.com/photo-1606811971618-4486d14f3f99?q=80&w=400&auto=format&fit=crop',
        description: 'Lower right quadrant showing healthy teeth structure',
        uploadDate: '2023-04-18'
      },
      {
        id: '2',
        checkupId: '1',
        imageUrl: 'https://images.unsplash.com/photo-1607613009820-a29f7bb81c04?q=80&w=400&auto=format&fit=crop',
        description: 'Upper left quadrant - small cavity detected',
        uploadDate: '2023-04-18'
      }
    ]
  }
];

// Create context
interface DentalContextType {
  dentists: Dentist[];
  checkupRequests: CheckupRequest[];
  checkupResults: CheckupResult[];
  createCheckupRequest: (request: Omit<CheckupRequest, 'id' | 'requestDate' | 'status'>) => void;
  uploadCheckupImage: (checkupId: string, imageUrl: string, description: string) => void;
  completeCheckup: (
    requestId: string, 
    diagnosis: string, 
    treatment: string, 
    notes: string, 
    images: Omit<CheckupImage, 'id' | 'uploadDate'>[]
  ) => void;
  getDentistRequests: (dentistId: string) => CheckupRequest[];
  getPatientRequests: (patientId: string) => CheckupRequest[];
  getPatientResults: (patientId: string) => CheckupResult[];
}

const DentalContext = createContext<DentalContextType | undefined>(undefined);

export const useDental = () => {
  const context = useContext(DentalContext);
  if (context === undefined) {
    throw new Error('useDental must be used within a DentalProvider');
  }
  return context;
};

interface DentalProviderProps {
  children: ReactNode;
}

export const DentalProvider = ({ children }: DentalProviderProps) => {
  const [dentists, setDentists] = useState<Dentist[]>(MOCK_DENTISTS);
  const [checkupRequests, setCheckupRequests] = useState<CheckupRequest[]>(MOCK_CHECKUP_REQUESTS);
  const [checkupResults, setCheckupResults] = useState<CheckupResult[]>(MOCK_CHECKUP_RESULTS);

  const createCheckupRequest = (request: Omit<CheckupRequest, 'id' | 'requestDate' | 'status'>) => {
    const newRequest: CheckupRequest = {
      ...request,
      id: `${checkupRequests.length + 1}`,
      requestDate: new Date().toISOString().split('T')[0],
      status: 'pending'
    };
    
    setCheckupRequests([...checkupRequests, newRequest]);
    toast.success('Checkup request submitted successfully!');
  };

  const uploadCheckupImage = (checkupId: string, imageUrl: string, description: string) => {
    // This is a simplified implementation - in a real app, you'd upload to a server
    const result = checkupResults.find(r => r.id === checkupId);
    
    if (result) {
      const newImage: CheckupImage = {
        id: `${result.images.length + 1}`,
        checkupId,
        imageUrl,
        description,
        uploadDate: new Date().toISOString().split('T')[0]
      };
      
      const updatedResults = checkupResults.map(r => {
        if (r.id === checkupId) {
          return {
            ...r,
            images: [...r.images, newImage]
          };
        }
        return r;
      });
      
      setCheckupResults(updatedResults);
      toast.success('Image uploaded successfully!');
    }
  };

  const completeCheckup = (
    requestId: string, 
    diagnosis: string, 
    treatment: string, 
    notes: string, 
    images: Omit<CheckupImage, 'id' | 'uploadDate'>[]
  ) => {
    // Find the associated request
    const request = checkupRequests.find(r => r.id === requestId);
    
    if (!request) {
      toast.error('Checkup request not found');
      return;
    }
    
    // Mark request as completed
    const updatedRequests = checkupRequests.map(r => {
      if (r.id === requestId) {
        return { ...r, status: 'completed' as const };
      }
      return r;
    });
    
    // Create a new checkup result
    const newResult: CheckupResult = {
      id: `${checkupResults.length + 1}`,
      requestId,
      patientId: request.patientId,
      patientName: request.patientName,
      dentistId: request.dentistId,
      dentistName: request.dentistName,
      date: new Date().toISOString().split('T')[0],
      diagnosis,
      treatment,
      notes,
      images: images.map((img, index) => ({
        ...img,
        id: `${index + 1}`,
        uploadDate: new Date().toISOString().split('T')[0]
      }))
    };
    
    setCheckupRequests(updatedRequests);
    setCheckupResults([...checkupResults, newResult]);
    toast.success('Checkup completed successfully!');
  };

  const getDentistRequests = (dentistId: string) => {
    return checkupRequests.filter(request => request.dentistId === dentistId);
  };

  const getPatientRequests = (patientId: string) => {
    return checkupRequests.filter(request => request.patientId === patientId);
  };

  const getPatientResults = (patientId: string) => {
    return checkupResults.filter(result => result.patientId === patientId);
  };

  return (
    <DentalContext.Provider value={{
      dentists,
      checkupRequests,
      checkupResults,
      createCheckupRequest,
      uploadCheckupImage,
      completeCheckup,
      getDentistRequests,
      getPatientRequests,
      getPatientResults
    }}>
      {children}
    </DentalContext.Provider>
  );
};
