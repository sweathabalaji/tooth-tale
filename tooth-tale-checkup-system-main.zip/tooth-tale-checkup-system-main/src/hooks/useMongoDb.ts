
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/sonner';

interface MongoDbOptions {
  collection: string;
}

interface QueryOptions {
  query?: Record<string, any>;
  update?: Record<string, any>;
  data?: any;
}

export function useMongoDb({ collection }: MongoDbOptions) {
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);

  const callMongoFunction = async (action: string, options: QueryOptions = {}) => {
    setLoading(true);
    setError(null);

    try {
      console.log(`Calling MongoDB ${action} on collection ${collection}`);
      const { data: responseData, error: responseError } = await supabase.functions.invoke('mongodb', {
        body: {
          action,
          collection,
          ...options
        }
      });

      // Check for response errors
      if (responseError) {
        console.error(`MongoDB ${action} response error:`, responseError);
        throw new Error(responseError.message || 'An error occurred with the MongoDB function');
      }
      
      // Check for missing data
      if (!responseData) {
        console.error(`MongoDB ${action} - No data returned`);
        throw new Error('No data returned from MongoDB function');
      }
      
      // Check for operation success
      if (!responseData.success) {
        console.error(`MongoDB ${action} operation failed:`, responseData.error);
        throw new Error(responseData.error || 'MongoDB operation failed');
      }
      
      console.log(`MongoDB ${action} success:`, responseData);
      return responseData;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
      setError(err instanceof Error ? err : new Error(errorMessage));
      console.error(`MongoDB ${action} error:`, err);
      
      // Show toast for better user experience
      toast.error(`MongoDB Error: ${errorMessage}`);
      
      return { success: false, error: errorMessage };
    } finally {
      setLoading(false);
    }
  };

  return {
    // Query methods
    find: (query?: Record<string, any>) => callMongoFunction('find', { query }),
    findOne: (query?: Record<string, any>) => callMongoFunction('findOne', { query }),
    
    // Update methods
    insertOne: (data: any) => callMongoFunction('insertOne', { data }),
    insertMany: (data: any[]) => callMongoFunction('insertMany', { data }),
    updateOne: (query: Record<string, any>, update: Record<string, any>) => 
      callMongoFunction('updateOne', { query, update }),
    updateMany: (query: Record<string, any>, update: Record<string, any>) => 
      callMongoFunction('updateMany', { query, update }),
    
    // Delete methods
    deleteOne: (query: Record<string, any>) => callMongoFunction('deleteOne', { query }),
    deleteMany: (query: Record<string, any>) => callMongoFunction('deleteMany', { query }),
    
    // Status
    loading,
    error
  };
}
