
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { MongoClient } from "https://deno.land/x/mongo@v0.31.1/mod.ts";

// CORS headers for browser requests
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get MongoDB connection string from environment variable
    // The correct secret name is the one that contains mongodb+srv
    const MONGODB_URI = Deno.env.get("mongodb+srv://sweathabalaji03:yCfgexwQfprNzEaP@cluster2.vogrufe.mongodb.net/?retryWrites");
    
    if (!MONGODB_URI) {
      console.error("MongoDB connection string not found");
      throw new Error("MongoDB connection string not found. Please check your Supabase secrets configuration.");
    }

    console.log("MongoDB connection string found successfully");

    // Parse the request body
    const { action, collection, data, query, update } = await req.json();

    if (!collection) {
      throw new Error("Collection name is required");
    }

    // Connect to MongoDB
    console.log("Attempting to connect to MongoDB...");
    const client = new MongoClient();
    await client.connect(MONGODB_URI);
    console.log("Connected to MongoDB successfully");

    // Get the database from the connection string
    const dbName = new URL(MONGODB_URI).pathname.substring(1);
    const db = client.database(dbName || "default");
    console.log(`Using database: ${dbName || "default"}`);

    // Get the specified collection
    const coll = db.collection(collection);
    let result;

    // Perform the requested action
    switch (action) {
      case "find":
        console.log(`Executing find with query:`, query || {});
        result = await coll.find(query || {}).toArray();
        break;
      case "findOne":
        console.log(`Executing findOne with query:`, query || {});
        result = await coll.findOne(query || {});
        break;
      case "insertOne":
        console.log(`Executing insertOne with data:`, data);
        result = await coll.insertOne(data);
        break;
      case "insertMany":
        console.log(`Executing insertMany with ${data?.length || 0} items`);
        result = await coll.insertMany(data);
        break;
      case "updateOne":
        console.log(`Executing updateOne with query:`, query);
        result = await coll.updateOne(query, update);
        break;
      case "updateMany":
        console.log(`Executing updateMany with query:`, query);
        result = await coll.updateMany(query, update);
        break;
      case "deleteOne":
        console.log(`Executing deleteOne with query:`, query);
        result = await coll.deleteOne(query);
        break;
      case "deleteMany":
        console.log(`Executing deleteMany with query:`, query);
        result = await coll.deleteMany(query);
        break;
      default:
        throw new Error(`Unsupported action: ${action}`);
    }

    // Close the MongoDB connection
    await client.close();
    console.log("Disconnected from MongoDB");

    // Return the result
    return new Response(JSON.stringify({ success: true, data: result }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error in MongoDB function:", error);
    return new Response(JSON.stringify({ success: false, error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
